import { create } from "zustand";
import { api } from "@/lib/api";
import { supabase } from "@/lib/supabase";
import type { LoginPayload, RegisterWomanPayload, SessionUser } from "@/types/domain";

const WOMAN_SEED_EMAIL_DOMAIN = "@exemplo.com";

function isWomanSeedAccount(email: string) {
  return email.trim().toLowerCase().endsWith(WOMAN_SEED_EMAIL_DOMAIN);
}

interface AuthState {
  currentUser: SessionUser | null;
  isAuthenticated: boolean;
  isBootstrapping: boolean;
  hydrate: () => Promise<void>;
  login: (payload: LoginPayload) => Promise<SessionUser>;
  registerWoman: (payload: RegisterWomanPayload) => Promise<SessionUser>;
  logout: () => Promise<void>;
}

export const useAuthStore = create<AuthState>((set) => ({
  currentUser: null,
  isAuthenticated: false,
  isBootstrapping: true,

  hydrate: async () => {
    try {
      const response = await api.me();
      set({
        currentUser: response.user,
        isAuthenticated: true,
        isBootstrapping: false,
      });
    } catch {
      if (supabase) {
        const { data } = await supabase.auth.getSession();
        const accessToken = data.session?.access_token;

        if (accessToken) {
          try {
            const response = await api.syncSupabaseWoman(accessToken);
            set({
              currentUser: response.user,
              isAuthenticated: true,
              isBootstrapping: false,
            });
            return;
          } catch {
            // Se a ponte falhar, a tela volta para login normal.
          }
        }
      }

      set({
        currentUser: null,
        isAuthenticated: false,
        isBootstrapping: false,
      });
    }
  },

  login: async (payload) => {
    if (payload.perfil === "mulher") {
      if (!supabase) {
        if (isWomanSeedAccount(payload.email)) {
          const response = await api.login(payload);
          set({
            currentUser: response.user,
            isAuthenticated: true,
          });
          return response.user;
        }

        throw new Error("O acesso da Mulher via Supabase ainda não foi configurado neste ambiente.");
      }

      const { data, error } = await supabase.auth.signInWithPassword({
        email: payload.email,
        password: payload.password,
      });

      if (error || !data.session?.access_token) {
        if (isWomanSeedAccount(payload.email)) {
          const response = await api.login(payload);
          set({
            currentUser: response.user,
            isAuthenticated: true,
          });
          return response.user;
        }

        throw new Error(error?.message ?? "Não foi possível autenticar a Mulher no Supabase.");
      }

      const response = await api.syncSupabaseWoman(data.session.access_token);
      set({
        currentUser: response.user,
        isAuthenticated: true,
      });
      return response.user;
    }

    const response = await api.login(payload);
    set({
      currentUser: response.user,
      isAuthenticated: true,
    });
    return response.user;
  },

  registerWoman: async (payload) => {
    if (!supabase) {
      throw new Error("O cadastro da Mulher via Supabase ainda não foi configurado neste ambiente.");
    }

    const { data, error } = await supabase.auth.signUp({
      email: payload.email,
      password: payload.password,
      options: {
        data: {
          nomeCompleto: payload.nomeCompleto,
          nomeSocial: payload.nomeSocial,
          cpf: payload.cpf,
          dataNascimento: payload.dataNascimento,
          telefone: payload.telefone,
          endereco: payload.endereco,
          municipio: payload.municipio,
          uf: payload.uf,
        },
      },
    });

    if (error) {
      throw new Error(error.message ?? "Não foi possível criar a conta da Mulher no Supabase.");
    }

    const accessToken = data.session?.access_token;
    if (!accessToken) {
      throw new Error("Conta criada. Confirme o e-mail no Supabase para concluir o primeiro acesso.");
    }

    const response = await api.syncSupabaseWoman(accessToken, payload);
    set({
      currentUser: response.user,
      isAuthenticated: true,
    });
    return response.user;
  },

  logout: async () => {
    await supabase?.auth.signOut().catch(() => undefined);
    await api.logout().catch(() => undefined);
    set({
      currentUser: null,
      isAuthenticated: false,
    });
  },
}));
