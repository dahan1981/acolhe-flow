import { useEffect, useMemo, useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Clock3, MessageCircleHeart, RefreshCw, Search, Send, ShieldCheck, UserRoundCheck } from "lucide-react";
import { toast } from "sonner";
import { useSearchParams } from "react-router-dom";
import { AppLayout } from "@/components/layout/AppLayout";
import { api } from "@/lib/api";
import { getOrganizationName } from "@/lib/domain";
import { useAuthStore } from "@/stores/auth-store";
import type { ChatStatus, ChatTicket } from "@/types/domain";

function getChatPageTitle(isWoman: boolean, canMonitor: boolean) {
  if (isWoman) return "Atendimento protegido";
  return canMonitor ? "Monitoramento de atendimentos" : "Fila de atendimentos protegidos";
}

function getChatPageSubtitle(isWoman: boolean, canMonitor: boolean) {
  if (isWoman) {
    return "Abra um chamado de atendimento especializado e acompanhe a conversa com a equipe responsável em um canal protegido.";
  }

  return canMonitor
    ? "Acompanhe chamados ativos, distribuição da fila e status de assunção pelas contas internas."
    : "Assuma chamados pendentes e conduza o atendimento especializado com continuidade operacional.";
}

function getTicketStatusLabel(status: ChatStatus) {
  if (status === "aguardando_assuncao") return "Aguardando assunção";
  if (status === "em_atendimento") return "Em atendimento";
  return "Encerrado";
}

function getConnectionLabel(status: "connecting" | "connected" | "reconnecting" | "disabled") {
  if (status === "disabled") return "Atualização automática por polling";
  if (status === "connected") return "Conexão em tempo real ativa";
  if (status === "reconnecting") return "Reconectando canal em tempo real";
  return "Estabelecendo canal em tempo real";
}

export default function ChatPage() {
  const { currentUser } = useAuthStore();
  const [searchParams, setSearchParams] = useSearchParams();
  const queryClient = useQueryClient();
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [statusFilter, setStatusFilter] = useState<"todos" | ChatStatus>("todos");
  const [search, setSearch] = useState("");
  const [message, setMessage] = useState("");
  const realtimeEnabled =
    typeof window !== "undefined" &&
    import.meta.env.VITE_DISABLE_REALTIME !== "true" &&
    !window.location.host.includes("vercel.app");
  const [socketStatus, setSocketStatus] = useState<"connecting" | "connected" | "reconnecting" | "disabled">(
    realtimeEnabled ? "connecting" : "disabled",
  );
  const [lastSyncAt, setLastSyncAt] = useState(() => new Date());
  const [pendingMessageId, setPendingMessageId] = useState<string | null>(null);
  const messageListRef = useRef<HTMLDivElement | null>(null);

  const isWoman = currentUser?.perfil === "mulher";
  const canActInternally = currentUser?.perfil === "profissional" || currentUser?.perfil === "gestora";
  const canMonitor = currentUser?.perfil === "gestora";

  const { data, isLoading, isFetching } = useQuery({
    queryKey: ["chat-tickets", currentUser?.id],
    queryFn: api.getChats,
    enabled: !!currentUser,
    refetchInterval: 5000,
    refetchIntervalInBackground: true,
    refetchOnWindowFocus: true,
    refetchOnReconnect: true,
  });

  const tickets = useMemo(() => data?.chats ?? [], [data?.chats]);
  const filteredTickets = useMemo(() => {
    const normalizedSearch = search.trim().toLowerCase();

    return tickets.filter((ticket) => {
      const matchesStatus = statusFilter === "todos" || ticket.status === statusFilter;
      const matchesSearch =
        !normalizedSearch ||
        ticket.ownerName.toLowerCase().includes(normalizedSearch) ||
        ticket.ownerEmail.toLowerCase().includes(normalizedSearch) ||
        (ticket.protocolo ?? "").toLowerCase().includes(normalizedSearch) ||
        ticket.assunto.toLowerCase().includes(normalizedSearch);

      return matchesStatus && matchesSearch;
    });
  }, [search, statusFilter, tickets]);

  const selectedTicket = useMemo(
    () => (selectedId ? filteredTickets.find((ticket) => ticket.id === selectedId) ?? null : filteredTickets[0] ?? null),
    [filteredTickets, selectedId],
  );

  useEffect(() => {
    setSelectedId((current) =>
      current && filteredTickets.some((ticket) => ticket.id === current) ? current : filteredTickets[0]?.id ?? null,
    );
    setLastSyncAt(new Date());
  }, [filteredTickets]);

  useEffect(() => {
    if (!selectedTicket || !messageListRef.current) return;
    messageListRef.current.scrollTop = messageListRef.current.scrollHeight;
  }, [selectedTicket]);

  useEffect(() => {
    if (!currentUser || !realtimeEnabled) {
      setSocketStatus("disabled");
      return;
    }

    let socket: WebSocket | null = null;
    let reconnectTimer: number | null = null;
    let closedByEffect = false;

    const connect = () => {
      const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
      socket = new WebSocket(`${protocol}//${window.location.host}/ws`);
      setSocketStatus("connecting");

      socket.addEventListener("open", () => {
        setSocketStatus("connected");
      });

      socket.addEventListener("message", (event) => {
        const payload = JSON.parse(event.data) as { type?: string };
        if (payload.type === "chat.updated") {
          setLastSyncAt(new Date());
          queryClient.invalidateQueries({ queryKey: ["chat-tickets", currentUser.id] });
        }
      });

      socket.addEventListener("close", () => {
        if (closedByEffect) return;
        setSocketStatus("reconnecting");
        reconnectTimer = window.setTimeout(connect, 2000);
      });
    };

    connect();

    return () => {
      closedByEffect = true;
      if (reconnectTimer) {
        window.clearTimeout(reconnectTimer);
      }
      socket?.close();
    };
  }, [currentUser, queryClient, realtimeEnabled]);

  const refreshChats = async () => {
    setLastSyncAt(new Date());
    await queryClient.invalidateQueries({ queryKey: ["chat-tickets", currentUser?.id] });
  };

  const createChatMutation = useMutation({
    mutationFn: (context?: string) => api.createChat(context),
    onSuccess: async ({ chat }) => {
      await refreshChats();
      setSelectedId(chat.id);
      toast.success("Canal de chat protegido aberto com sucesso.");
    },
    onError: (error) => {
      toast.error(error instanceof Error ? error.message : "Não foi possível abrir o chat.");
    },
  });

  const sendMessageMutation = useMutation({
    mutationFn: ({ id, body }: { id: string; body: string }) => api.sendChatMessage(id, body),
    onSuccess: async ({ chat }) => {
      setMessage("");
      setPendingMessageId(null);
      await refreshChats();
      setSelectedId(chat.id);
    },
    onError: (error) => {
      setPendingMessageId(null);
      toast.error(error instanceof Error ? error.message : "Não foi possível enviar a mensagem.");
    },
  });

  const assumeMutation = useMutation({
    mutationFn: (id: string) => api.assumeChat(id),
    onSuccess: async ({ chat }) => {
      await refreshChats();
      setSelectedId(chat.id);
      toast.success("Chat assumido pela conta interna responsável.");
    },
    onError: (error) => {
      toast.error(error instanceof Error ? error.message : "Não foi possível assumir o chat.");
    },
  });

  const closeMutation = useMutation({
    mutationFn: (id: string) => api.closeChat(id),
    onSuccess: async ({ chat }) => {
      await refreshChats();
      setSelectedId(chat.id);
      toast.success("Chat encerrado com sucesso.");
    },
    onError: (error) => {
      toast.error(error instanceof Error ? error.message : "Não foi possível encerrar o chat.");
    },
  });

  useEffect(() => {
    if (!currentUser || currentUser.perfil !== "mulher") return;
    if (searchParams.get("start") !== "1") return;

    createChatMutation.mutate("Solicitação aberta a partir de atendimento especializado.");
    setSearchParams({}, { replace: true });
  }, [createChatMutation, currentUser, searchParams, setSearchParams]);

  if (!currentUser) return null;

  function openSupportChat() {
    createChatMutation.mutate("Solicitação aberta a partir de atendimento especializado.");
  }

  function handleSendMessage() {
    if (!selectedTicket || !message.trim()) return;
    setPendingMessageId(selectedTicket.id);
    sendMessageMutation.mutate({ id: selectedTicket.id, body: message.trim() });
  }

  function handleAssume() {
    if (!selectedTicket) return;
    assumeMutation.mutate(selectedTicket.id);
  }

  function handleClose() {
    if (!selectedTicket) return;
    closeMutation.mutate(selectedTicket.id);
  }

  function handleMessageKeyDown(event: React.KeyboardEvent<HTMLTextAreaElement>) {
    if (event.key !== "Enter" || event.shiftKey) return;
    event.preventDefault();
    handleSendMessage();
  }

  function getUnreadLabel(ticket: ChatTicket) {
    return isWoman ? `${ticket.unreadForWoman} nova(s)` : `${ticket.unreadForTeam} pendência(s)`;
  }

  const queueSummary = {
    total: tickets.length,
    aguardando: tickets.filter((ticket) => ticket.status === "aguardando_assuncao").length,
    ativos: tickets.filter((ticket) => ticket.status === "em_atendimento").length,
    encerrados: tickets.filter((ticket) => ticket.status === "encerrado").length,
  };

  const queueCards = [
    { label: "Fila total", value: queueSummary.total },
    { label: "Aguardando", value: queueSummary.aguardando },
    { label: "Em atendimento", value: queueSummary.ativos },
    { label: "Encerrados", value: queueSummary.encerrados },
  ];

  const activeQueueCards = [
    { label: "Fila visível", value: filteredTickets.length },
    { label: "Não lidos", value: isWoman ? selectedTicket?.unreadForWoman ?? 0 : selectedTicket?.unreadForTeam ?? 0 },
  ];

  return (
    <AppLayout title={getChatPageTitle(!!isWoman, !!canMonitor)} subtitle={getChatPageSubtitle(!!isWoman, !!canMonitor)}>
      <div className="space-y-4">
        <section className="rounded-[26px] border border-primary/15 bg-card/95 p-5 shadow-card">
          <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-primary/10 bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
            <ShieldCheck className="h-3.5 w-3.5" />
            Canal protegido
          </div>
          <h2 className="text-lg font-semibold text-foreground">
            {isWoman ? "Canal seguro com a equipe de apoio" : "Fila de atendimentos com assunção institucional"}
          </h2>
          <p className="mt-1 text-sm text-muted-foreground">
            {isWoman
              ? "Use este canal quando precisar de orientação psicossocial, jurídica ou intersetorial, com registro de histórico vinculado à sua conta."
              : "Os chamados abaixo podem ser assumidos por contas internas ativas para resposta rápida, registro adequado e articulação segura da rede."}
          </p>
          <div className="mt-3 inline-flex items-center gap-2 rounded-full bg-background px-3 py-1 text-[11px] font-medium text-muted-foreground">
            <span
              className={`h-2.5 w-2.5 rounded-full ${
                socketStatus === "connected" ? "bg-emerald-500" : socketStatus === "disabled" ? "bg-sky-500" : "bg-amber-500"
              }`}
            />
            {getConnectionLabel(socketStatus)}
          </div>
          <div className="mt-3 flex flex-wrap items-center justify-between gap-3 text-xs text-muted-foreground">
            <div className="inline-flex items-center gap-2">
              <Clock3 className="h-3.5 w-3.5" />
              Última sincronização: {lastSyncAt.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit", second: "2-digit" })}
            </div>
            <button
              type="button"
              onClick={refreshChats}
              className="inline-flex items-center gap-2 rounded-full border border-border/70 bg-background px-3 py-1.5 text-[11px] font-medium text-foreground"
            >
              <RefreshCw className={`h-3.5 w-3.5 ${isFetching ? "animate-spin" : ""}`} />
              Atualizar agora
            </button>
          </div>
          {isWoman ? (
            <button
              onClick={openSupportChat}
              disabled={createChatMutation.isPending}
              className="mt-4 flex w-full items-center justify-center gap-2 rounded-2xl bg-primary px-4 py-4 text-base font-semibold text-primary-foreground shadow-card transition-all hover:shadow-card-hover disabled:opacity-70"
            >
              <MessageCircleHeart className="h-4 w-4" />
              {tickets.length ? "Retomar atendimento em andamento" : "Iniciar atendimento especializado"}
            </button>
          ) : null}
          {isWoman ? (
            <p className="mt-3 text-xs text-muted-foreground">
              Assim que o chamado for aberto, ele passa a ficar visível para a equipe interna autorizada, e todo o histórico permanece vinculado à sua conta.
            </p>
          ) : null}
        </section>

        {!isWoman ? (
          <section className="grid grid-cols-2 gap-3 lg:grid-cols-4">
            {queueCards.map((card) => (
              <div key={card.label} className="min-h-[112px] rounded-[24px] border border-border/70 bg-card/90 p-4 shadow-card">
                <p className="text-[11px] font-semibold uppercase tracking-[0.12em] text-muted-foreground">{card.label}</p>
                <p className="mt-3 text-3xl font-semibold leading-none text-foreground tabular-nums">{card.value}</p>
              </div>
            ))}
          </section>
        ) : null}

        <section className="space-y-3">
          <div className="rounded-[24px] border border-border/70 bg-card/90 p-4 shadow-card">
            <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
              <div>
                <p className="text-xs font-semibold uppercase tracking-[0.16em] text-muted-foreground">
                  {isWoman ? "Minhas conversas" : "Fila operacional"}
                </p>
                <p className="mt-1 text-sm text-muted-foreground">
                  {isWoman
                    ? "Acompanhe o atendimento ativo, retome a conversa quando necessário e mantenha todo o histórico acessível pela sua conta."
                    : "Use busca e filtros para localizar rapidamente o atendimento certo antes de assumir, responder ou encerrar a condução."}
                </p>
              </div>
              <div className="grid grid-cols-2 gap-2 lg:w-[220px]">
                {activeQueueCards.map((card) => (
                  <div key={card.label} className="rounded-2xl bg-background px-3 py-3">
                    <p className="text-[11px] uppercase tracking-[0.12em] text-muted-foreground">{card.label}</p>
                    <p className="mt-2 text-xl font-semibold text-foreground tabular-nums">{card.value}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-4 flex flex-col gap-3 lg:flex-row">
              <label className="flex min-w-0 flex-1 items-center gap-2 rounded-2xl border border-border/70 bg-background px-4 py-3">
                <Search className="h-4 w-4 text-muted-foreground" />
                <input
                  value={search}
                  onChange={(event) => setSearch(event.target.value)}
                  placeholder={isWoman ? "Buscar por protocolo ou assunto" : "Buscar por nome, protocolo ou assunto"}
                  className="min-w-0 flex-1 bg-transparent text-sm text-foreground outline-none placeholder:text-muted-foreground"
                />
              </label>

              <div className="flex flex-wrap gap-2">
                {([
                  { value: "todos", label: "Todos" },
                  { value: "aguardando_assuncao", label: "Aguardando" },
                  { value: "em_atendimento", label: "Em atendimento" },
                  { value: "encerrado", label: "Encerrados" },
                ] as const).map((option) => (
                  <button
                    key={option.value}
                    type="button"
                    onClick={() => setStatusFilter(option.value)}
                    className={`rounded-full px-3 py-2 text-xs font-medium transition-colors ${
                      statusFilter === option.value
                        ? "bg-primary text-primary-foreground"
                        : "border border-border/70 bg-background text-muted-foreground"
                    }`}
                  >
                    {option.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {isLoading ? (
            <div className="rounded-[24px] border border-dashed border-border/70 bg-card/80 p-5 text-sm text-muted-foreground">
              Carregando chamados...
            </div>
          ) : filteredTickets.length ? (
            filteredTickets.map((ticket) => (
              <button
                key={ticket.id}
                onClick={() => setSelectedId(ticket.id)}
                className={`w-full rounded-[24px] border p-4 text-left shadow-card transition-all ${
                  selectedTicket?.id === ticket.id ? "border-primary/30 bg-primary/5" : "border-border/70 bg-card/90"
                }`}
              >
                <div className="mb-2 flex flex-wrap items-start justify-between gap-2">
                  <p className="min-w-0 flex-1 text-sm font-semibold text-foreground">{ticket.ownerName}</p>
                  <span className="shrink-0 rounded-full bg-background px-2.5 py-1 text-[11px] font-medium text-muted-foreground">
                    {getTicketStatusLabel(ticket.status)}
                  </span>
                </div>
                <p className="text-xs text-muted-foreground">
                  {ticket.protocolo ? `Protocolo ${ticket.protocolo}` : "Sem protocolo vinculado"} - {ticket.assunto}
                </p>
                <p className="mt-2 line-clamp-2 text-sm text-muted-foreground">{ticket.context}</p>
                <div className="mt-3 flex items-center justify-between gap-3 text-xs text-muted-foreground">
                  <span>{new Date(ticket.updatedAt).toLocaleString("pt-BR")}</span>
                  <span>{getUnreadLabel(ticket)}</span>
                </div>
              </button>
            ))
          ) : (
            <div className="rounded-[24px] border border-dashed border-border/70 bg-card/80 p-5 text-sm text-muted-foreground">
              {tickets.length
                ? "Nenhum chamado corresponde aos filtros aplicados no momento."
                : isWoman
                  ? "Nenhum atendimento aberto no momento. Inicie um novo chamado para falar com a equipe de apoio."
                  : "Nenhum atendimento protegido está aguardando assunção neste momento."}
            </div>
          )}
        </section>

        <section className="rounded-[26px] border border-border/70 bg-card/95 p-4 shadow-card">
          {selectedTicket ? (
            <div className="space-y-4">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-semibold text-foreground">{selectedTicket.ownerName}</p>
                  <p className="text-xs text-muted-foreground">
                    {selectedTicket.protocolo ? `Protocolo ${selectedTicket.protocolo}` : "Caso em abertura"} - fila de atendimento especializado
                  </p>
                </div>
                <div className="max-w-full text-left text-xs text-muted-foreground">
                  <p>{selectedTicket.assignedProfessionalName ? "Assumido por" : "Sem responsável"}</p>
                  <p className="font-medium text-foreground">
                    {selectedTicket.assignedProfessionalName || (canMonitor ? "Aguardando equipe" : "Aguardando assunção")}
                  </p>
                </div>
              </div>

              <div className="grid gap-3 sm:grid-cols-3">
                <div className="rounded-[20px] bg-background px-4 py-3">
                  <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">Status atual</p>
                  <p className="mt-2 text-sm font-semibold text-foreground">{getTicketStatusLabel(selectedTicket.status)}</p>
                </div>
                <div className="rounded-[20px] bg-background px-4 py-3">
                  <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">Último movimento</p>
                  <p className="mt-2 text-sm font-semibold text-foreground">{new Date(selectedTicket.updatedAt).toLocaleString("pt-BR")}</p>
                </div>
                <div className="rounded-[20px] bg-background px-4 py-3">
                  <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">Mensagens</p>
                  <p className="mt-2 text-sm font-semibold text-foreground">{selectedTicket.messages.length} registro(s)</p>
                </div>
              </div>

              <div className="rounded-[24px] bg-background px-4 py-3 text-sm text-muted-foreground">
                <p className="mb-1 text-xs font-semibold uppercase tracking-[0.16em] text-muted-foreground">Contexto do chamado</p>
                {selectedTicket.context}
              </div>

              {(canActInternally || canMonitor) && selectedTicket.caseId ? (
                <div className="rounded-[24px] bg-background px-4 py-3 text-sm text-muted-foreground">
                  <p className="mb-1 text-xs font-semibold uppercase tracking-[0.16em] text-muted-foreground">Vínculo operacional</p>
                  Caso conectado ao fluxo principal da rede. O histórico continua acessível no detalhe do caso e no órgão atual: {getOrganizationName("sec-mulher")}.
                </div>
              ) : null}

              <div ref={messageListRef} className="max-h-[420px] space-y-3 overflow-y-auto rounded-[24px] bg-background p-3">
                {selectedTicket.messages.map((item) => {
                  const isOwn =
                    (currentUser.perfil === "mulher" && item.senderProfile === "mulher") ||
                    (canActInternally && (item.senderProfile === "profissional" || item.senderProfile === "gestora"));
                  const isSystem = item.senderProfile === "sistema";

                  return (
                    <div key={item.id} className={`flex ${isOwn ? "justify-end" : "justify-start"}`}>
                      <div
                        className={`max-w-[88%] break-words rounded-[22px] px-4 py-3 text-sm shadow-card ${
                          isSystem
                            ? "bg-muted text-muted-foreground"
                            : isOwn
                              ? "bg-primary text-primary-foreground"
                              : "border border-border/70 bg-card text-foreground"
                        }`}
                      >
                        <p className="mb-1 text-[11px] font-medium opacity-80">{item.senderName}</p>
                        <p>{item.body}</p>
                        <p className="mt-2 text-[11px] opacity-70">{new Date(item.createdAt).toLocaleString("pt-BR")}</p>
                      </div>
                    </div>
                  );
                })}
                {pendingMessageId === selectedTicket.id ? (
                  <div className="flex justify-end">
                    <div className="max-w-[88%] rounded-[22px] bg-primary/15 px-4 py-3 text-sm text-primary shadow-card">
                      <p className="mb-1 text-[11px] font-medium opacity-80">Enviando</p>
                      <p>{message}</p>
                    </div>
                  </div>
                ) : null}
              </div>

              <div className="space-y-3">
                {canActInternally && selectedTicket.status === "aguardando_assuncao" ? (
                  <button
                    onClick={handleAssume}
                    disabled={assumeMutation.isPending}
                    className="flex w-full items-center justify-center gap-2 rounded-2xl bg-accent px-4 py-3 text-sm font-semibold text-accent-foreground shadow-card disabled:opacity-70"
                  >
                    <UserRoundCheck className="h-4 w-4" />
                    Assumir como conta interna
                  </button>
                ) : null}

                {selectedTicket.status !== "encerrado" && (isWoman || canActInternally) ? (
                  <div className="flex gap-2">
                    <textarea
                      value={message}
                      onChange={(event) => setMessage(event.target.value)}
                      onKeyDown={handleMessageKeyDown}
                      rows={2}
                      placeholder={
                        isWoman
                          ? "Escreva sua mensagem para a equipe. Enter envia; Shift+Enter insere quebra de linha."
                          : "Registrar resposta no atendimento. Enter envia; Shift+Enter insere quebra de linha."
                      }
                      className="min-h-[72px] min-w-0 flex-1 resize-none rounded-2xl border border-border bg-background px-4 py-3 text-sm text-foreground outline-none transition-all focus:border-primary"
                    />
                    <button
                      type="button"
                      onClick={handleSendMessage}
                      disabled={!message.trim() || sendMessageMutation.isPending}
                      className="flex h-[72px] w-[64px] shrink-0 items-center justify-center rounded-2xl bg-primary text-primary-foreground shadow-card disabled:opacity-50"
                    >
                      {sendMessageMutation.isPending ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                    </button>
                  </div>
                ) : null}

                {canActInternally && selectedTicket.status !== "encerrado" ? (
                  <button
                    onClick={handleClose}
                    disabled={closeMutation.isPending}
                    className="w-full rounded-2xl border border-border bg-background px-4 py-3 text-sm font-medium text-foreground disabled:opacity-70"
                  >
                    Encerrar atendimento protegido
                  </button>
                ) : null}
              </div>
            </div>
          ) : (
            <div className="rounded-[24px] border border-dashed border-border/70 bg-background p-8 text-center text-sm text-muted-foreground">
              {isWoman
                ? "Abra um atendimento especializado para visualizar a conversa, acompanhar a resposta da equipe e manter o histórico protegido nesta conta."
                : "Selecione um atendimento para visualizar a conversa, o contexto do chamado e o histórico associado."}
            </div>
          )}
        </section>
      </div>
    </AppLayout>
  );
}
