import { useMemo } from "react";
import type { ElementType } from "react";
import { useQuery } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { Activity, AlertTriangle, BarChart3, Clock, FilePlus2, ShieldCheck, Stethoscope, Users } from "lucide-react";
import { AppLayout } from "@/components/layout/AppLayout";
import { api } from "@/lib/api";
import { ethnicityLabel, violenceTypeLabel } from "@/lib/domain";
import { roleDescriptions } from "@/lib/demo-content";

export default function GestoraDashboard() {
  const navigate = useNavigate();
  const { data, isLoading } = useQuery({
    queryKey: ["manager-dashboard"],
    queryFn: api.getManagerDashboard,
  });

  const stats = data?.stats;

  const topViolence = useMemo(
    () => [...(stats?.porViolencia ?? [])].sort((a, b) => b.total - a.total).slice(0, 3),
    [stats?.porViolencia],
  );

  const topEthnicity = useMemo(
    () => [...(stats?.porEtnia ?? [])].sort((a, b) => b.total - a.total).slice(0, 3),
    [stats?.porEtnia],
  );

  if (isLoading || !stats) {
    return (
      <AppLayout>
        <p className="text-sm text-muted-foreground">Carregando painel gerencial...</p>
      </AppLayout>
    );
  }

  const hasOperationalData = stats.total > 0 || stats.totalAtendimentos > 0 || stats.encaminhamentosPendentes > 0;

  return (
    <AppLayout
      title="Painel gerencial"
      subtitle="Indicadores consolidados para acompanhar desempenho, distribuição operacional e leitura executiva da plataforma."
    >
      <div className="space-y-6">
        <section className="rounded-[30px] border border-white/60 bg-card/90 p-5 shadow-card">
          <div className="mb-2 inline-flex items-center gap-2 rounded-full border border-primary/10 bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
            <ShieldCheck className="h-3.5 w-3.5" />
            Monitoramento executivo
          </div>
          <h2 className="text-xl font-semibold text-foreground">Leitura executiva da rede e governança do fluxo</h2>
          <p className="mt-1 text-sm leading-6 text-muted-foreground">{roleDescriptions.gestora}</p>
          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            <button
              onClick={() => navigate("/gestora/novo-protocolo")}
              className="rounded-[24px] bg-primary px-4 py-4 text-left text-sm font-medium text-primary-foreground shadow-card"
            >
              <div className="mb-1 flex items-center gap-2">
                <FilePlus2 className="h-4 w-4" />
                Gerar protocolo
              </div>
              <p className="text-xs text-primary-foreground/80">Abrir um novo caso sob supervisão da gestão</p>
            </button>
            <button
              onClick={() => navigate("/gestora/novo-atendimento")}
              className="rounded-[24px] border border-border/70 bg-background px-4 py-4 text-left text-sm font-medium text-foreground shadow-card"
            >
              <div className="mb-1 flex items-center gap-2">
                <Stethoscope className="h-4 w-4 text-accent" />
                Registrar atendimento
              </div>
              <p className="text-xs text-muted-foreground">Atualizar um caso ou apoiar a condução operacional da equipe</p>
            </button>
            <button
              onClick={() => navigate("/gestora/administracao")}
              className="rounded-[24px] border border-border/70 bg-background px-4 py-3 text-left text-sm font-medium text-foreground shadow-card"
            >
              <p className="text-xs uppercase tracking-[0.18em] text-muted-foreground">Equipe</p>
              Administrar equipe
            </button>
            <button
              onClick={() => navigate("/gestora/chats")}
              className="rounded-[24px] border border-border/70 bg-background px-4 py-3 text-left text-sm font-medium text-foreground shadow-card"
            >
              <p className="text-xs uppercase tracking-[0.18em] text-muted-foreground">Fila protegida</p>
              Monitorar atendimentos
            </button>
          </div>
        </section>

        {!hasOperationalData ? (
          <section className="rounded-[24px] border border-dashed border-border/70 bg-card/85 p-5 shadow-card">
            <h3 className="text-base font-semibold text-foreground">Base operacional pronta para iniciar registros</h3>
            <p className="mt-2 text-sm leading-6 text-muted-foreground">
              Não há casos, atendimentos ou encaminhamentos registrados neste momento. A gestão já pode iniciar a operação pelo cadastro do primeiro protocolo, acompanhar novos atendimentos protegidos ou concluir a organização das contas internas responsáveis.
            </p>
            <div className="mt-4 grid gap-3 sm:grid-cols-3">
              <button
                onClick={() => navigate("/gestora/novo-protocolo")}
                className="rounded-2xl bg-primary px-4 py-3 text-sm font-semibold text-primary-foreground shadow-card"
              >
                Abrir primeiro protocolo
              </button>
              <button
                onClick={() => navigate("/gestora/chats")}
                className="rounded-2xl border border-border/70 bg-background px-4 py-3 text-sm font-medium text-foreground shadow-card"
              >
                Ver fila de atendimentos
              </button>
              <button
                onClick={() => navigate("/gestora/administracao")}
                className="rounded-2xl border border-border/70 bg-background px-4 py-3 text-sm font-medium text-foreground shadow-card"
              >
                Revisar equipe interna
              </button>
            </div>
          </section>
        ) : null}

        <section className="grid grid-cols-2 gap-3">
          <MetricCard icon={Users} label="Casos monitorados" value={stats.total} />
          <MetricCard icon={Activity} label="Atendimentos" value={stats.totalAtendimentos} accent="accent" />
          <MetricCard icon={AlertTriangle} label="Casos em triagem" value={stats.ativos} accent="warning" />
          <MetricCard icon={Clock} label="Encaminhamentos pendentes" value={stats.encaminhamentosPendentes} accent="urgent" />
        </section>

        <section className="grid gap-4 lg:grid-cols-[1.3fr_1fr]">
          <div className="rounded-[24px] border border-border/70 bg-card/90 p-5 shadow-card">
            <div className="mb-4 flex items-center gap-2">
              <BarChart3 className="h-4 w-4 text-primary" />
              <h3 className="text-sm font-semibold text-foreground">Status dos casos</h3>
            </div>
            <div className="space-y-3">
              {[
                { label: "Triagem", count: stats.ativos, total: stats.total, className: "bg-urgent" },
                { label: "Em andamento", count: stats.emAndamento, total: stats.total, className: "bg-primary" },
                { label: "Encaminhados", count: stats.encaminhados, total: stats.total, className: "bg-warning" },
                { label: "Concluídos", count: stats.resolvidos, total: stats.total, className: "bg-accent" },
              ].map((item) => (
                <div key={item.label}>
                  <div className="mb-1 flex justify-between text-sm">
                    <span className="text-muted-foreground">{item.label}</span>
                    <span className="font-medium tabular-nums text-foreground">{item.count}</span>
                  </div>
                  <div className="h-2 overflow-hidden rounded-full bg-muted">
                    <div
                      className={`h-full rounded-full ${item.className}`}
                      style={{ width: `${item.total ? (item.count / item.total) * 100 : 0}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="rounded-[24px] border border-border/70 bg-card/90 p-5 shadow-card">
            <h3 className="mb-4 text-sm font-semibold text-foreground">Distribuição de risco</h3>
            <div className="grid grid-cols-2 gap-3">
              {stats.porRisco.map((item) => (
                <div key={item.nivel} className="rounded-[22px] border border-border/60 bg-background px-3 py-3">
                  <div className="mb-2 flex items-center gap-2">
                    <div className={`h-3 w-3 rounded-full ${riskColorClass(item.cor)}`} />
                    <p className="text-xs text-muted-foreground">{item.nivel}</p>
                  </div>
                  <p className="text-xl font-bold tabular-nums text-foreground">{item.total}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="grid gap-4 lg:grid-cols-2">
          <InsightList
            title="Tipos de violência mais recorrentes"
            items={topViolence.map((item) => ({ label: violenceTypeLabel(item.tipo), value: item.total }))}
            emptyText="Sem registros suficientes para destacar recortes nesta etapa."
          />
          <InsightList
            title="Recorte por etnia/cor"
            items={topEthnicity.map((item) => ({ label: ethnicityLabel(item.etnia), value: item.total }))}
            emptyText="Sem registros suficientes para consolidar o recorte atual."
          />
        </section>

        <section className="rounded-[24px] border border-border/70 bg-card/90 p-5 shadow-card">
          <h3 className="mb-4 text-sm font-semibold text-foreground">Distribuição por órgão</h3>
          {stats.porOrgao.length ? (
            <div className="space-y-3">
              {stats.porOrgao.map((item) => (
                <div key={item.sigla} className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10">
                      <span className="text-xs font-bold text-primary">{item.sigla}</span>
                    </div>
                    <span className="text-sm text-foreground">{item.orgao}</span>
                  </div>
                  <span className="text-sm font-semibold tabular-nums text-foreground">{item.total}</span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm leading-6 text-muted-foreground">
              Nenhum órgão possui volume consolidado ainda. A distribuição aparecerá automaticamente com a entrada dos primeiros casos registrados no ambiente.
            </p>
          )}
        </section>
      </div>
    </AppLayout>
  );
}

function MetricCard({
  icon: Icon,
  label,
  value,
  accent = "primary",
}: {
  icon: ElementType;
  label: string;
  value: number;
  accent?: "primary" | "accent" | "warning" | "urgent";
}) {
  const accentClass =
    accent === "accent" ? "text-accent" : accent === "warning" ? "text-warning" : accent === "urgent" ? "text-urgent" : "text-primary";

  return (
    <div className="rounded-[24px] border border-border/70 bg-card/90 p-4 shadow-card">
      <div className="mb-2 flex items-center gap-2">
        <Icon className={`h-4 w-4 ${accentClass}`} />
        <span className="text-xs text-muted-foreground">{label}</span>
      </div>
      <p className="text-3xl font-bold tabular-nums text-foreground">{value}</p>
    </div>
  );
}

function InsightList({
  title,
  items,
  emptyText,
}: {
  title: string;
  items: Array<{ label: string; value: number }>;
  emptyText: string;
}) {
  return (
    <div className="rounded-[24px] border border-border/70 bg-card/90 p-5 shadow-card">
      <h3 className="mb-4 text-sm font-semibold text-foreground">{title}</h3>
      {items.length ? (
        <div className="space-y-3">
          {items.map((item) => (
            <div key={item.label} className="flex items-center justify-between rounded-[22px] border border-border/60 bg-background px-4 py-3">
              <span className="text-sm text-foreground">{item.label}</span>
              <span className="text-sm font-semibold tabular-nums text-foreground">{item.value}</span>
            </div>
          ))}
        </div>
      ) : (
        <p className="text-sm text-muted-foreground">{emptyText}</p>
      )}
    </div>
  );
}

function riskColorClass(color: string) {
  if (color === "urgent") return "bg-urgent";
  if (color === "warning") return "bg-warning";
  if (color === "accent") return "bg-accent";
  return "bg-primary";
}
