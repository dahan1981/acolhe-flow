import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Heart, Users, BarChart3, CheckCircle2, Sparkles } from "lucide-react";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { AthenaMark } from "@/components/brand/AthenaMark";
import { useAuthStore } from "@/stores/auth-store";
import type { RegisterWomanPayload, UserProfile } from "@/types/domain";

const profiles: Array<{ id: UserProfile; label: string; desc: string; icon: React.ElementType }> = [
  { id: "mulher", label: "Mulher", desc: "Acompanhe seu caso e solicite apoio com segurança", icon: Heart },
  { id: "profissional", label: "Profissional", desc: "Conduza atendimentos, protocolos e encaminhamentos", icon: Users },
  { id: "gestora", label: "Gestora", desc: "Monitore indicadores, equipe e governança operacional", icon: BarChart3 },
];

const initialRegisterState: RegisterWomanPayload = {
  nomeCompleto: "",
  nomeSocial: "",
  email: "",
  password: "",
  cpf: "",
  dataNascimento: "",
  telefone: "",
  endereco: "",
  municipio: "",
  uf: "RJ",
};

function homePath(profile: UserProfile) {
  if (profile === "mulher") return "/mulher";
  if (profile === "profissional") return "/profissional";
  return "/gestora";
}

export default function Login() {
  const navigate = useNavigate();
  const { login, registerWoman } = useAuthStore();
  const [selectedProfile, setSelectedProfile] = useState<UserProfile>("mulher");
  const [mode, setMode] = useState<"login" | "register">("login");
  const [loginForm, setLoginForm] = useState({ email: "", password: "" });
  const [registerForm, setRegisterForm] = useState(initialRegisterState);
  const [isSubmitting, setIsSubmitting] = useState(false);

  async function handleLoginSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setIsSubmitting(true);

    try {
      const user = await login({
        ...loginForm,
        perfil: selectedProfile,
      });
      navigate(homePath(user.perfil));
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Não foi possível entrar.");
    } finally {
      setIsSubmitting(false);
    }
  }

  async function handleRegisterSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setIsSubmitting(true);

    try {
      const user = await registerWoman(registerForm);
      toast.success("Cadastro criado com sucesso.");
      navigate(homePath(user.perfil));
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Não foi possível criar a conta.");
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <div className="relative min-h-screen overflow-hidden bg-[linear-gradient(180deg,#f7f2ff_0%,#f5effc_34%,#f3eef9_100%)] px-6 py-8">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_12%_18%,rgba(177,130,231,0.34),transparent_24%),radial-gradient(circle_at_84%_16%,rgba(120,68,192,0.22),transparent_20%),radial-gradient(circle_at_50%_78%,rgba(214,194,243,0.34),transparent_30%),linear-gradient(135deg,rgba(255,255,255,0.52),transparent_38%,rgba(255,255,255,0.2))]" />
      <div className="pointer-events-none absolute inset-x-0 top-0 h-56 bg-[linear-gradient(180deg,rgba(255,255,255,0.42),rgba(255,255,255,0))]" />
      <div className="pointer-events-none absolute left-1/2 top-16 h-72 w-72 -translate-x-1/2 rounded-full bg-primary/10 blur-3xl" />

      <div className="relative mx-auto flex min-h-[calc(100vh-4rem)] w-full max-w-6xl items-center justify-center gap-8">
        <div className="hidden max-w-md flex-1 lg:block">
          <div className="rounded-[34px] border border-white/65 bg-white/72 p-8 shadow-elevated backdrop-blur-xl">
            <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-primary/10 bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
              <Sparkles className="h-3.5 w-3.5" />
              Plataforma em operação assistida
            </div>

            <div className="flex items-center gap-4">
              <AthenaMark className="h-16 w-16 shrink-0 drop-shadow-[0_10px_20px_rgba(79,38,111,0.18)]" />
              <div>
                <h1 className="bg-gradient-to-r from-foreground via-primary to-accent bg-clip-text text-4xl font-semibold text-transparent">
                  Athena
                </h1>
                <p className="mt-2 text-sm font-medium uppercase tracking-[0.22em] text-muted-foreground">Proteção à mulher</p>
              </div>
            </div>
            <p className="mt-3 text-base leading-8 text-muted-foreground">
              Plataforma para acolhimento, acompanhamento e monitoramento integrado da rede de atendimento à mulher, estruturada para operação assistida e validação institucional.
            </p>

            <div className="mt-8 space-y-3">
              {[
                "Ambientes dedicados para Mulher, Profissional e Gestora, com leitura adequada para cada perfil.",
                "Jornadas completas com dashboards, históricos, protocolos, atendimentos e áreas institucionais.",
                "Fluxos acompanhados por equipe autorizada, com foco em continuidade, rastreabilidade e governança.",
              ].map((item) => (
                <div
                  key={item}
                  className="flex items-start gap-3 rounded-[24px] border border-white/60 bg-white/72 px-4 py-4 shadow-card"
                >
                  <CheckCircle2 className="mt-0.5 h-4 w-4 text-accent" />
                  <p className="text-sm leading-6 text-muted-foreground">{item}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="flex w-full max-w-md flex-col items-center justify-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: [0.4, 0, 0.2, 1] }}
            className="w-full max-w-md"
          >
            <div className="mb-8 text-center">
              <AthenaMark className="mx-auto mb-4 h-20 w-20 drop-shadow-[0_16px_28px_rgba(79,38,111,0.2)]" />
              <h1 className="bg-gradient-to-r from-foreground via-primary to-accent bg-clip-text text-3xl font-semibold text-transparent">
                Athena
              </h1>
              <p className="mx-auto mt-2 max-w-sm text-sm leading-6 text-muted-foreground">
                Acesso institucional para acolhimento, atendimento e monitoramento integrado da rede.
              </p>
            </div>

            <div className="grid grid-cols-3 gap-2.5 mb-4">
              {profiles.map((profile) => (
                <button
                  key={profile.id}
                  type="button"
                  onClick={() => {
                    setSelectedProfile(profile.id);
                    if (profile.id !== "mulher") setMode("login");
                  }}
                  className={`rounded-[26px] border p-3 text-left transition-all ${
                    selectedProfile === profile.id
                      ? "border-primary/20 bg-gradient-to-br from-primary to-accent text-primary-foreground shadow-card"
                      : "border-white/65 bg-white/72 shadow-card backdrop-blur-md"
                  }`}
                >
                  <profile.icon className="mb-2 h-5 w-5" />
                  <p className="text-sm font-semibold">{profile.label}</p>
                  <p
                    className={`text-[11px] leading-4 ${
                      selectedProfile === profile.id ? "text-primary-foreground/80" : "text-muted-foreground"
                    }`}
                  >
                    {profile.desc}
                  </p>
                </button>
              ))}
            </div>

            {selectedProfile === "mulher" && (
              <div className="mb-4 flex gap-2">
                <button
                  type="button"
                  onClick={() => setMode("login")}
                  className={`flex-1 rounded-2xl py-2.5 text-sm font-medium ${
                    mode === "login"
                      ? "bg-gradient-to-r from-primary to-accent text-primary-foreground shadow-card"
                      : "border border-white/65 bg-white/72 text-muted-foreground shadow-card"
                  }`}
                >
                  Acessar conta
                </button>
                <button
                  type="button"
                  onClick={() => setMode("register")}
                  className={`flex-1 rounded-2xl py-2.5 text-sm font-medium ${
                    mode === "register"
                      ? "bg-gradient-to-r from-primary to-accent text-primary-foreground shadow-card"
                      : "border border-white/65 bg-white/72 text-muted-foreground shadow-card"
                  }`}
                >
                  Criar cadastro
                </button>
              </div>
            )}

            {mode === "login" || selectedProfile !== "mulher" ? (
              <form
                onSubmit={handleLoginSubmit}
                className="space-y-4 rounded-[34px] border border-white/65 bg-white/76 p-6 shadow-elevated backdrop-blur-xl"
              >
                <div>
                  <h2 className="text-lg font-semibold text-foreground">Acesso seguro</h2>
                  <p className="mt-1 text-sm leading-6 text-muted-foreground">
                    {selectedProfile === "mulher"
                      ? "O acesso da Mulher acontece via autenticação protegida no Supabase, com sincronização segura para a Athena."
                      : "Informe suas credenciais para continuar no ambiente correspondente ao seu perfil."}
                  </p>
                </div>
                <div>
                  <label className="text-sm font-medium text-foreground">E-mail</label>
                  <input
                    type="email"
                    required
                    value={loginForm.email}
                    onChange={(event) => setLoginForm((current) => ({ ...current, email: event.target.value }))}
                    className="mt-1 w-full rounded-2xl border border-primary/10 bg-white/88 px-4 py-3 text-sm outline-none transition-all focus:ring-2 focus:ring-primary/20"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium text-foreground">Senha</label>
                  <input
                    type="password"
                    required
                    value={loginForm.password}
                    onChange={(event) => setLoginForm((current) => ({ ...current, password: event.target.value }))}
                    className="mt-1 w-full rounded-2xl border border-primary/10 bg-white/88 px-4 py-3 text-sm outline-none transition-all focus:ring-2 focus:ring-primary/20"
                  />
                </div>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full rounded-[22px] bg-gradient-to-r from-primary to-accent px-6 py-4 text-base font-semibold text-primary-foreground shadow-card transition-all duration-200 hover:shadow-card-hover active:scale-[0.98] disabled:opacity-70"
                >
                  {isSubmitting ? "Validando acesso..." : `Entrar como ${profiles.find((item) => item.id === selectedProfile)?.label}`}
                </button>
                <p className="text-center text-xs leading-6 text-muted-foreground">
                  {selectedProfile === "mulher"
                    ? "Cadastro e acesso da Mulher usam Supabase. Perfis internos continuam sob administração local da equipe responsável."
                    : "Perfis internos são administrados localmente pela equipe responsável."}
                </p>
              </form>
            ) : (
              <form
                onSubmit={handleRegisterSubmit}
                className="space-y-4 rounded-[34px] border border-white/65 bg-white/76 p-6 shadow-elevated backdrop-blur-xl"
              >
                <div>
                  <h2 className="text-lg font-semibold text-foreground">Cadastro inicial</h2>
                  <p className="mt-1 text-sm leading-6 text-muted-foreground">
                    Preencha seus dados para iniciar o acompanhamento pela Athena em ambiente assistido.
                  </p>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="col-span-2">
                    <label className="text-sm font-medium text-foreground">Nome completo</label>
                    <input
                      type="text"
                      required
                      value={registerForm.nomeCompleto}
                      onChange={(event) => setRegisterForm((current) => ({ ...current, nomeCompleto: event.target.value }))}
                      className="mt-1 w-full rounded-2xl border border-primary/10 bg-white/88 px-4 py-3 text-sm outline-none transition-all focus:ring-2 focus:ring-primary/20"
                    />
                  </div>
                  <div className="col-span-2">
                    <label className="text-sm font-medium text-foreground">Nome social</label>
                    <input
                      type="text"
                      value={registerForm.nomeSocial}
                      onChange={(event) => setRegisterForm((current) => ({ ...current, nomeSocial: event.target.value }))}
                      className="mt-1 w-full rounded-2xl border border-primary/10 bg-white/88 px-4 py-3 text-sm outline-none transition-all focus:ring-2 focus:ring-primary/20"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium text-foreground">CPF</label>
                    <input
                      type="text"
                      required
                      value={registerForm.cpf}
                      onChange={(event) => setRegisterForm((current) => ({ ...current, cpf: event.target.value }))}
                      className="mt-1 w-full rounded-2xl border border-primary/10 bg-white/88 px-4 py-3 text-sm outline-none transition-all focus:ring-2 focus:ring-primary/20"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium text-foreground">Nascimento</label>
                    <input
                      type="date"
                      required
                      value={registerForm.dataNascimento}
                      onChange={(event) => setRegisterForm((current) => ({ ...current, dataNascimento: event.target.value }))}
                      className="mt-1 w-full rounded-2xl border border-primary/10 bg-white/88 px-4 py-3 text-sm outline-none transition-all focus:ring-2 focus:ring-primary/20"
                    />
                  </div>
                  <div className="col-span-2">
                    <label className="text-sm font-medium text-foreground">Telefone</label>
                    <input
                      type="text"
                      required
                      value={registerForm.telefone}
                      onChange={(event) => setRegisterForm((current) => ({ ...current, telefone: event.target.value }))}
                      className="mt-1 w-full rounded-2xl border border-primary/10 bg-white/88 px-4 py-3 text-sm outline-none transition-all focus:ring-2 focus:ring-primary/20"
                    />
                  </div>
                  <div className="col-span-2">
                    <label className="text-sm font-medium text-foreground">Endereco</label>
                    <input
                      type="text"
                      required
                      value={registerForm.endereco}
                      onChange={(event) => setRegisterForm((current) => ({ ...current, endereco: event.target.value }))}
                      className="mt-1 w-full rounded-2xl border border-primary/10 bg-white/88 px-4 py-3 text-sm outline-none transition-all focus:ring-2 focus:ring-primary/20"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium text-foreground">Municipio</label>
                    <input
                      type="text"
                      required
                      value={registerForm.municipio}
                      onChange={(event) => setRegisterForm((current) => ({ ...current, municipio: event.target.value }))}
                      className="mt-1 w-full rounded-2xl border border-primary/10 bg-white/88 px-4 py-3 text-sm outline-none transition-all focus:ring-2 focus:ring-primary/20"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium text-foreground">UF</label>
                    <input
                      type="text"
                      required
                      maxLength={2}
                      value={registerForm.uf}
                      onChange={(event) => setRegisterForm((current) => ({ ...current, uf: event.target.value.toUpperCase() }))}
                      className="mt-1 w-full rounded-2xl border border-primary/10 bg-white/88 px-4 py-3 text-sm outline-none transition-all focus:ring-2 focus:ring-primary/20"
                    />
                  </div>
                  <div className="col-span-2">
                    <label className="text-sm font-medium text-foreground">E-mail</label>
                    <input
                      type="email"
                      required
                      value={registerForm.email}
                      onChange={(event) => setRegisterForm((current) => ({ ...current, email: event.target.value }))}
                      className="mt-1 w-full rounded-2xl border border-primary/10 bg-white/88 px-4 py-3 text-sm outline-none transition-all focus:ring-2 focus:ring-primary/20"
                    />
                  </div>
                  <div className="col-span-2">
                    <label className="text-sm font-medium text-foreground">Senha</label>
                    <input
                      type="password"
                      required
                      minLength={8}
                      value={registerForm.password}
                      onChange={(event) => setRegisterForm((current) => ({ ...current, password: event.target.value }))}
                      className="mt-1 w-full rounded-2xl border border-primary/10 bg-white/88 px-4 py-3 text-sm outline-none transition-all focus:ring-2 focus:ring-primary/20"
                    />
                  </div>
                </div>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full rounded-[22px] bg-gradient-to-r from-primary to-accent px-6 py-4 text-base font-semibold text-primary-foreground shadow-card transition-all duration-200 hover:shadow-card-hover active:scale-[0.98] disabled:opacity-70"
                >
                  {isSubmitting ? "Criando cadastro..." : "Concluir cadastro"}
                </button>
              </form>
            )}
          </motion.div>

          <p className="mt-8 text-center text-xs leading-6 text-muted-foreground">
            Ambiente institucional com acesso acompanhado por equipes autorizadas.
          </p>
        </div>
      </div>
    </div>
  );
}
