import { useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { ArrowRight, Bell, BookHeart, Clock, Shield, Sparkles } from "lucide-react";
import { AppLayout } from "@/components/layout/AppLayout";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { api } from "@/lib/api";
import { roleDescriptions } from "@/lib/demo-content";
import { formatDate, getOrganizationName } from "@/lib/domain";

export default function MulherDashboard() {
  const navigate = useNavigate();
  const { data, isLoading } = useQuery({
    queryKey: ["woman-dashboard"],
    queryFn: api.getWomanDashboard,
  });

  if (isLoading) {
    return (
      <AppLayout>
        <p className="text-sm text-muted-foreground">Carregando seu caso...</p>
      </AppLayout>
    );
  }

  const caso = data?.caso;

  if (!caso) {
    return (
      <AppLayout
        title="Minha área"
        subtitle="Acompanhe sua situação com clareza, registre uma nova solicitação e acione a equipe quando precisar de apoio."
      >
        <div className="space-y-5">
          <div className="rounded-[30px] border border-white/60 bg-card/90 p-5 shadow-card">
            <div className="inline-flex items-center gap-2 rounded-full bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
              <Sparkles className="h-3.5 w-3.5" />
              Início guiado
            </div>
            <h2 className="mt-3 text-xl font-semibold text-foreground">Seu acompanhamento começa por um registro inicial seguro</h2>
            <p className="mt-2 text-sm leading-6 text-muted-foreground">{roleDescriptions.mulher}</p>
            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              <button
                onClick={() => navigate("/mulher/ajuda")}
                className="rounded-[24px] bg-primary px-4 py-4 text-left font-semibold text-primary-foreground shadow-card"
              >
                Registrar solicitação
                <p className="mt-1 text-xs font-medium text-primary-foreground/80">
                  Informe o que aconteceu e abra seu acompanhamento inicial.
                </p>
              </button>
              <button
                onClick={() => navigate("/mulher/chat")}
                className="rounded-[24px] border border-border/70 bg-background px-4 py-4 text-left font-semibold text-foreground shadow-card"
              >
                Falar com a equipe
                <p className="mt-1 text-xs font-medium text-muted-foreground">
                  Use o chat protegido para acolhimento e orientação imediata.
                </p>
              </button>
            </div>
          </div>

          <div>
            <div className="mb-3 flex items-center justify-between">
              <h2 className="text-sm font-semibold text-foreground">Próximos passos</h2>
              <span className="text-xs text-muted-foreground">Fluxo guiado</span>
            </div>
            <div className="grid gap-3">
              {[
                {
                  title: "1. Registrar a necessidade atual",
                  description: "Abra uma solicitação com risco, relato inicial e tipo de apoio necessário.",
                },
                {
                  title: "2. Acompanhar o caso",
                  description: "Assim que o primeiro registro for concluído, protocolo, status e timeline aparecerão nesta área.",
                },
                {
                  title: "3. Acionar atendimento especializado",
                  description: "Quando precisar de contato direto com a equipe, use o chat protegido para orientação mais rápida.",
                },
              ].map((step) => (
                <section key={step.title} className="rounded-[24px] border border-border/70 bg-card/90 p-4 shadow-card">
                  <p className="text-sm font-semibold text-foreground">{step.title}</p>
                  <p className="mt-1 text-sm text-muted-foreground">{step.description}</p>
                </section>
              ))}
            </div>
          </div>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout
      title="Minha área"
      subtitle="Visualize protocolo, status do caso, orientações e canais de contato em um único lugar."
    >
      <div className="space-y-6">
        <div className="rounded-[30px] border border-white/60 bg-card/90 p-5 shadow-card">
          <div className="mb-4 flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-primary/10">
              <Shield className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="text-xs uppercase tracking-[0.22em] text-muted-foreground">Acompanhamento ativo</p>
              <p className="font-semibold text-foreground">Protocolo {caso.protocolo}</p>
            </div>
          </div>
          <div className="mb-3 flex flex-wrap items-center gap-2">
            <StatusBadge type="status" value={caso.status} />
            <StatusBadge type="risk" value={caso.situacaoRisco} />
          </div>
          <p className="text-sm leading-6 text-muted-foreground">
            Seu caso está sendo acompanhado por {getOrganizationName(caso.orgaoAtual)}. O último registro foi feito em{" "}
            {formatDate(caso.atendimentos[0]?.data || caso.dataPrimeiroAtendimento)}.
          </p>
          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            <button
              onClick={() => navigate("/mulher/historico")}
              className="rounded-[24px] border border-border/70 bg-background px-4 py-3 text-left text-sm font-medium text-foreground shadow-card"
            >
              <p className="text-xs uppercase tracking-[0.18em] text-muted-foreground">Histórico</p>
              Ver histórico
            </button>
            <button
              onClick={() => navigate("/mulher/notificacoes")}
              className="rounded-[24px] border border-border/70 bg-background px-4 py-3 text-left text-sm font-medium text-foreground shadow-card"
            >
              <p className="text-xs uppercase tracking-[0.18em] text-muted-foreground">Alertas</p>
              Abrir alertas
            </button>
            <button
              onClick={() => navigate("/mulher/chat")}
              className="col-span-2 rounded-[24px] bg-gradient-to-r from-primary to-accent px-4 py-4 text-left text-sm font-semibold text-primary-foreground shadow-card"
            >
              Canal de acolhimento especializado
              <p className="mt-1 text-xs font-medium text-primary-foreground/80">
                Acione a equipe para orientação psicossocial, jurídica ou intersetorial.
              </p>
            </button>
          </div>
        </div>

        <div>
          <div className="mb-3 flex items-center justify-between">
          <h2 className="text-sm font-semibold text-foreground">Acessos rápidos</h2>
            <button onClick={() => navigate("/mulher/central-ajuda")} className="text-xs font-medium text-primary">
              Central de ajuda
            </button>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {["Apoio jurídico", "Saúde", "Abrigo", "Assistência social"].map((item) => (
              <button
                key={item}
                onClick={() => navigate("/mulher/ajuda")}
                className="rounded-[24px] border border-border/70 bg-card/90 p-4 text-left shadow-card transition-all hover:shadow-card-hover active:scale-[0.98]"
              >
                <p className="text-sm font-medium text-foreground">{item}</p>
                <p className="mt-1 text-xs text-muted-foreground">Solicitar apoio</p>
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={() => navigate("/mulher/caso")}
            className="rounded-[24px] border border-border/70 bg-card/90 p-4 text-left shadow-card"
          >
            <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Status</p>
            <p className="mt-2 text-sm font-semibold text-foreground">Acompanhar meu caso</p>
          </button>
          <button
            onClick={() => navigate("/mulher/perfil")}
            className="rounded-[24px] border border-border/70 bg-card/90 p-4 text-left shadow-card"
          >
            <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Conta</p>
            <p className="mt-2 text-sm font-semibold text-foreground">Perfil e configurações</p>
          </button>
        </div>

        <div>
          <h2 className="mb-3 text-sm font-semibold text-foreground">Atividade recente</h2>
          {data?.atendimentosRecentes.length ? (
            <div className="space-y-3">
              {data.atendimentosRecentes.slice(0, 3).map((item) => (
                <div key={item.id} className="rounded-[24px] border border-border/70 bg-card/90 p-4 shadow-card">
                  <div className="mb-1 flex items-center gap-2">
                    <Clock className="w-3.5 h-3.5 text-muted-foreground" />
                    <span className="text-xs text-muted-foreground">{formatDate(item.data)}</span>
                  </div>
                  <p className="text-sm font-medium text-foreground">{item.tipoAtendimento}</p>
                  <p className="mt-1 text-xs text-muted-foreground">{getOrganizationName(item.orgao)}</p>
                </div>
              ))}
            </div>
          ) : (
            <div className="rounded-[24px] border border-dashed border-border/70 bg-card/80 p-4 text-sm text-muted-foreground shadow-card">
              Ainda não há atendimento registrado no seu histórico. As movimentações aparecerão aqui conforme a equipe atualizar o caso.
            </div>
          )}
        </div>

        <div>
          <h2 className="mb-3 text-sm font-semibold text-foreground">Encaminhamentos ativos</h2>
          {data?.encaminhamentosRecentes.length ? (
            <div className="space-y-3 rounded-[24px] border border-border/70 bg-card/90 p-4 shadow-card">
              {data.encaminhamentosRecentes.map((item) => (
                <div key={item.id} className="flex items-center gap-3">
                  <ArrowRight className="w-4 h-4 shrink-0 text-accent" />
                  <div className="min-w-0 flex-1">
                    <p className="text-sm text-foreground">{getOrganizationName(item.orgaoDestino)}</p>
                    <p className="text-xs text-muted-foreground">{formatDate(item.data)}</p>
                  </div>
                  <StatusBadge type="encaminhamento" value={item.status} />
                </div>
              ))}
            </div>
          ) : (
            <div className="rounded-[24px] border border-dashed border-border/70 bg-card/80 p-4 text-sm text-muted-foreground shadow-card">
              Nenhum encaminhamento ativo no momento. Se houver articulação com outro órgão da rede, ela aparecerá aqui com status e data.
            </div>
          )}
        </div>

        {data?.solicitacoesApoio.length ? (
          <div>
            <h2 className="mb-3 text-sm font-semibold text-foreground">Solicitações de apoio</h2>
            <div className="space-y-3 rounded-[24px] border border-border/70 bg-card/90 p-4 shadow-card">
              {data.solicitacoesApoio.map((item) => (
                <div key={item.id} className="flex items-center gap-3">
                  <Bell className="w-4 h-4 shrink-0 text-primary" />
                  <div>
                    <p className="text-sm text-foreground">{item.tipo}</p>
                    <p className="text-xs text-muted-foreground">{new Date(item.data).toLocaleString("pt-BR")}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : null}

        <div className="rounded-[24px] border border-border/70 bg-card/90 p-5 shadow-card">
          <div className="mb-2 flex items-center gap-2">
            <BookHeart className="h-4 w-4 text-accent" />
            <h3 className="text-sm font-semibold text-foreground">Orientação rápida</h3>
          </div>
          <p className="text-sm leading-6 text-muted-foreground">
            Este ambiente foi organizado para facilitar o acompanhamento do caso com clareza e segurança. As principais ações ficam visíveis logo na entrada, com acesso rápido ao registro de solicitação, histórico do caso e central de orientações.
          </p>
        </div>
      </div>
    </AppLayout>
  );
}
