import { useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { ArrowRightLeft, Clock, FilePlus2, FileText, ShieldCheck, Stethoscope, Users } from "lucide-react";
import { AppLayout } from "@/components/layout/AppLayout";
import { CaseCard } from "@/components/shared/CaseCard";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { api } from "@/lib/api";
import { roleDescriptions } from "@/lib/demo-content";
import { formatDate, getOrganizationName } from "@/lib/domain";

export default function ProfissionalDashboard() {
  const navigate = useNavigate();
  const { data, isLoading } = useQuery({
    queryKey: ["professional-dashboard"],
    queryFn: api.getProfessionalDashboard,
  });

  if (isLoading) {
    return (
      <AppLayout>
        <p className="text-sm text-muted-foreground">Carregando painel profissional...</p>
      </AppLayout>
    );
  }

  const hasCases = (data?.casosPrioritarios.length ?? 0) > 0;
  const hasAttendances = (data?.ultimosAtendimentos.length ?? 0) > 0;

  return (
    <AppLayout
      title="Painel operacional"
      subtitle="Priorize atendimentos, acesse casos ativos e registre novas movimentações com mais clareza no fluxo da rede."
    >
      <div className="space-y-6">
        <div className="rounded-[30px] border border-white/60 bg-card/90 p-5 shadow-card">
          <div className="mb-2 inline-flex items-center gap-2 rounded-full border border-primary/10 bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
            <ShieldCheck className="h-3.5 w-3.5" />
            Operação institucional
          </div>
          <h2 className="text-xl font-semibold text-foreground">Condução do atendimento em um único painel</h2>
          <p className="mt-1 text-sm leading-6 text-muted-foreground">{roleDescriptions.profissional}</p>
          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            <button
              onClick={() => navigate("/profissional/novo-protocolo")}
              className="rounded-[24px] bg-primary px-4 py-4 text-left text-sm font-medium text-primary-foreground shadow-card"
            >
              <div className="mb-1 flex items-center gap-2">
                <FilePlus2 className="h-4 w-4" />
                Novo protocolo
              </div>
              <p className="text-xs text-primary-foreground/80">Cadastrar a pessoa atendida e iniciar um novo caso</p>
            </button>
            <button
              onClick={() => navigate("/profissional/novo-atendimento")}
              className="rounded-[24px] border border-border/70 bg-background px-4 py-4 text-left text-sm font-medium text-foreground shadow-card"
            >
              <div className="mb-1 flex items-center gap-2">
                <Stethoscope className="h-4 w-4 text-accent" />
                Novo atendimento
              </div>
              <p className="text-xs text-muted-foreground">
                Selecionar um caso existente, registrar atendimento e atualizar o andamento
              </p>
            </button>
            <button
              onClick={() => navigate("/profissional/historico")}
              className="rounded-[24px] border border-border/70 bg-background px-4 py-3 text-left text-sm font-medium text-foreground shadow-card"
            >
              <p className="text-xs uppercase tracking-[0.18em] text-muted-foreground">Histórico</p>
              Histórico operacional
            </button>
            <button
              onClick={() => navigate("/profissional/chats")}
              className="rounded-[24px] border border-border/70 bg-background px-4 py-3 text-left text-sm font-medium text-foreground shadow-card"
            >
              <p className="text-xs uppercase tracking-[0.18em] text-muted-foreground">Fila protegida</p>
              Atendimentos protegidos
            </button>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="rounded-[24px] border border-border/70 bg-card/90 p-4 shadow-card">
            <div className="mb-2 flex items-center gap-2">
              <Users className="w-4 h-4 text-primary" />
              <span className="text-xs text-muted-foreground">Casos ativos</span>
            </div>
            <p className="text-2xl font-bold tabular-nums text-foreground">{data?.casosAtivos ?? 0}</p>
          </div>
          <div className="rounded-[24px] border border-border/70 bg-card/90 p-4 shadow-card">
            <div className="mb-2 flex items-center gap-2">
              <FileText className="w-4 h-4 text-accent" />
              <span className="text-xs text-muted-foreground">Atendimentos hoje</span>
            </div>
            <p className="text-2xl font-bold tabular-nums text-foreground">{data?.atendimentosHoje ?? 0}</p>
          </div>
        </div>

        <div>
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-sm font-semibold text-foreground">Casos que pedem leitura imediata</h2>
            <button onClick={() => navigate("/profissional/casos")} className="text-xs font-medium text-primary">
              Ver todos
            </button>
          </div>
          {hasCases ? (
            <div className="space-y-3">
              {data?.casosPrioritarios.map((caso) => (
                <CaseCard key={caso.id} caso={caso} />
              ))}
            </div>
          ) : (
            <div className="rounded-[24px] border border-dashed border-border/70 bg-card/80 p-5 text-sm text-muted-foreground shadow-card">
              Nenhum caso prioritário disponível no momento. Assim que um protocolo ou uma solicitação entrar no fluxo da rede, ele passará a aparecer aqui para triagem e acompanhamento.
            </div>
          )}
        </div>

        <div>
          <h2 className="mb-3 text-sm font-semibold text-foreground">Últimos atendimentos registrados</h2>
          {hasAttendances ? (
            <div className="space-y-3">
              {data?.ultimosAtendimentos.map((item) => (
                <div key={item.id} className="rounded-[24px] border border-border/70 bg-card/90 p-4 shadow-card">
                  <div className="mb-1 flex items-center gap-2">
                    <Clock className="w-3.5 h-3.5 text-muted-foreground" />
                    <span className="text-xs text-muted-foreground">{formatDate(item.data)}</span>
                    <StatusBadge type="risk" value={item.riscoIdentificado} />
                  </div>
                  <p className="text-sm font-medium text-foreground">{item.caso.nomeSocial || item.caso.nomeCompleto}</p>
                  <p className="mt-1 text-xs text-muted-foreground">
                    {item.tipoAtendimento} - {getOrganizationName(item.orgao)}
                  </p>
                </div>
              ))}
            </div>
          ) : (
            <div className="rounded-[24px] border border-dashed border-border/70 bg-card/80 p-5 text-sm text-muted-foreground shadow-card">
              Ainda não há atendimentos registrados nesta conta. O primeiro atendimento salvo passa a compor o histórico operacional e a timeline compartilhada do caso.
            </div>
          )}
        </div>

        <div className="rounded-[24px] border border-border/70 bg-card/90 p-5 shadow-card">
          <div className="mb-2 flex items-center gap-2">
            <ArrowRightLeft className="h-4 w-4 text-accent" />
            <h3 className="text-sm font-semibold text-foreground">Continuidade do atendimento</h3>
          </div>
          <p className="text-sm leading-6 text-muted-foreground">
            A equipe pode alternar entre fila, detalhe do caso, registro de atendimento, encaminhamento, ajuda e permissões sem perder o contexto do atendimento em curso.
          </p>
        </div>
      </div>
    </AppLayout>
  );
}
